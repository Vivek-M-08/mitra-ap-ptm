import os
import re
import csv
import json
import requests
import psycopg2
import pandas as pd
import argparse
import concurrent.futures
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "localhost"),
    "port":     int(os.getenv("DB_PORT", 5432)),
    "database": os.getenv("DB_NAME", "mitra_ap_ptm"),
    "user":     os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "postgres"),
}

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2:3b" #"llama3.2:1b" #"qwen2.5:1.5b" #"llama3.2:3b" 
OUTPUT_CSV   = f"output/ratings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
BOT_ID       = 1

CATEGORIES = [
    "EDUCATION_QUALITY_RATING",
    "PRINCIPAL_SATISFACTION",
    "CARETAKER_SATISFACTION",
    "TEACHER_COMMUNICATION_RATING",
    "CLEANLINESS_RATING",
    "DRINKING_WATER_RATING",
    "HEALTHCARE_RATING",
    "DIET_MENU_RATING",
    "SAFETY_MEASURES_RATING",
    "EXTRACURRICULAR_RATING",
    "OVERALL_SATISFACTION_RATING",
]

CATEGORIES_WITH_REASON = set(CATEGORIES)

# ── Database ──────────────────────────────────────────────────────────────────
def get_connection():
    return psycopg2.connect(**DB_CONFIG)


def fetch_session_ids(conn, limit=15):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT DISTINCT session AS session_id
        FROM chatbot_companychat
        WHERE stage IN ({placeholders})
        LIMIT %s;
    """
    with conn.cursor() as cur:
        cur.execute(query, (*CATEGORIES, limit))
        return [r[0] for r in cur.fetchall()]


def fetch_session_messages(conn, session_id):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT session AS session_id, stage, sender_id, receiver_id, message, translated_message
        FROM chatbot_companychat
        WHERE session = %s
          AND stage IN ({placeholders})
        ORDER BY id ASC;
    """
    with conn.cursor() as cur:
        cur.execute(query, (session_id, *CATEGORIES))
        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]
    return pd.DataFrame(rows, columns=cols)


# ── LLM ───────────────────────────────────────────────────────────────────────
def build_prompt(session_id, stage_groups):
    convo_text = ""
    for stage, messages in stage_groups.items():
        convo_text += f"\n### STAGE: {stage}\n"
        for m in messages:
            role = "BOT" if m["sender_id"] == BOT_ID else "USER"
            msg_text = m.get("message")
            
            if role == "USER":
                translated = m.get("translated_message")
                if pd.notna(translated) and str(translated).strip():
                    msg_text = str(translated).strip()
                    
            convo_text += f"  [{role}]: {msg_text}\n"

    keys = []
    for cat in CATEGORIES:
        keys.append(f'"{cat}": <integer 1-5 or null>')
        if cat in CATEGORIES_WITH_REASON:
            keys.append(f'"{cat}_reason": "<string or null>"')

    expected_json = "{\n  " + ",\n  ".join(keys) + "\n}"

    return f"""
You are a data extraction assistant. A chatbot survey conversation is grouped below by stage.
Each stage has BOT questions and USER responses.
USER responses contain a numeric rating (1-5) and sometimes a reason text.

Rules:
- Extract the numeric rating (1-5) for every stage. Use null if not found.
- Extract the reason text from the USER's response for every stage. Use null if not found.
- You MUST return a JSON object containing ALL the keys listed in the Expected JSON.
- Do not omit any keys. If a value is missing, output null.
- Only extract from USER messages.
- Return ONLY valid JSON. No markdown. No explanation. No extra text.

SESSION: {session_id}

CONVERSATION:
{convo_text}

Expected JSON format (MUST OUTPUT ALL THESE KEYS):
{expected_json}
""".strip()


def call_ollama(prompt):
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.0, "num_predict": 1024},
    }
    try:
        # Increased timeout to 600s to handle massive parallel M1 workloads
        resp = requests.post(OLLAMA_URL, json=payload, timeout=600)
        resp.raise_for_status()
        raw = resp.json().get("response", "")
        cleaned = re.sub(r"```(?:json)?|```", "", raw).strip()
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            print(f"  ⚠️  No JSON block found. Raw:\n{raw[:300]}")
            return {}
        return json.loads(match.group())
    except json.JSONDecodeError as e:
        print(f"  ❌ JSON parse error: {e}")
        return {}
    except requests.RequestException as e:
        print(f"  ❌ Ollama error: {e}")
        return {}


# ── CSV ───────────────────────────────────────────────────────────────────────
def build_csv_columns():
    cols = ["session_id"]
    for cat in CATEGORIES:
        cols.append(cat)
        if cat in CATEGORIES_WITH_REASON:
            cols.append(f"{cat}_reason")
    return cols


def build_csv_row(session_id, extracted):
    row = {"session_id": session_id}
    for cat in CATEGORIES:
        row[cat] = extracted.get(cat)
        if cat in CATEGORIES_WITH_REASON:
            row[f"{cat}_reason"] = extracted.get(f"{cat}_reason")
    return row


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Extract chatbot ratings")
    parser.add_argument("session_id", type=str, nargs="?", help="Optional specific session ID to process")
    parser.add_argument("--limit", type=int, default=15, help="Number of sessions to process in batch mode")
    args = parser.parse_args()

    os.makedirs("output", exist_ok=True)

    print("🔌 Connecting to database...")
    conn = get_connection()

    if args.session_id:
        print(f"📋 Processing single session ID: {args.session_id}...")
        session_ids = [args.session_id]
        output_csv = f"output/rating_{args.session_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    else:
        print(f"📋 Fetching {args.limit} session IDs...")
        session_ids = fetch_session_ids(conn, limit=args.limit)
        print(f"  Found {len(session_ids)} sessions.\n")
        output_csv = OUTPUT_CSV

    csv_columns = build_csv_columns()
    all_rows = []

    print(f"📋 Fetching messages from database for {len(session_ids)} sessions...")
    session_data = {}
    for idx, sid in enumerate(session_ids, 1):
        df = fetch_session_messages(conn, sid)
        if df.empty:
            all_rows.append({"session_id": sid})
            continue

        stage_groups = {
            stage: group[["sender_id", "message", "translated_message"]].to_dict("records")
            for stage, group in df.groupby("stage", sort=False)
        }
        session_data[sid] = stage_groups
        
    conn.close()

    def process_llm(sid, stage_groups):
        prompt = build_prompt(sid, stage_groups)
        extracted = call_ollama(prompt)
        print(f"  ✅ [Session {sid}] {json.dumps(extracted, ensure_ascii=False)}")
        return build_csv_row(sid, extracted)

    print(f"🚀 Starting LLM extraction with 10 parallel threads...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_sid = {executor.submit(process_llm, sid, groups): sid for sid, groups in session_data.items()}
        
        for future in concurrent.futures.as_completed(future_to_sid):
            sid = future_to_sid[future]
            try:
                row = future.result()
                all_rows.append(row)
            except Exception as exc:
                print(f"⚠️  Session {sid} generated an exception: {exc}")
                all_rows.append({"session_id": sid})

    if not all_rows:
        print("⚠️ No data extracted.")
        return

    print(f"\n💾 Writing to {output_csv}...")
    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"✅ Done → {output_csv}")


if __name__ == "__main__":
    main()
