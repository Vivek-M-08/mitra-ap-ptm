# Data Row Count Comparison Analysis

I have compared the row counts from the CSV files with the actual row counts in the `mitra_ap_ptm` database.

## Row Count Comparison Summary

| Table / CSV File | CSV Rows (excluding header) | DB Row Count | Match |
| :--- | :---: | :---: | :---: |
| `chatbot_chatsession` / `chatbot_chatsessions.csv` | 35,179 | 35,179 | ✅ **Yes** |
| `chatbot_profile` / `chatbot_profile.csv` | 16,104 | 16,104 | ✅ **Yes** |
| `chatbot_companychat` / `chatbot_companychat.csv` | 631,113 | 618,067 | ❌ **No** (Diff: 13,046) |
| `chatbot_companystatemachine` / `chatbot_companystatemachine.csv` | 953 | 29 | ❌ **No** (Diff: 924) |

## Key Observations

### ✅ Matches
*   Both **`chatbot_chatsession`** and **`chatbot_profile`** show a perfect 1:1 match between the CSV data and the database contents, indicating a successful and complete import.

### ❌ Discrepancies

#### 1. `chatbot_companychat`
*   **Total Difference**: 13,046 fewer rows in the database.
*   **Duplicates**: A check revealed **926 duplicate IDs** in the CSV. Since the import script uses `ON CONFLICT (id) DO NOTHING`, these duplicates were skipped.
*   **Other Potential Causes**: The remaining difference (~12k rows) may be due to data validation errors (e.g., malformed JSON in `other_params` or timestamp parsing issues) that were skipped or not handled during the import process.

#### 2. `chatbot_companystatemachine`
*   **Total Difference**: 924 fewer rows in the database.
*   **Unique IDs**: The CSV contains 953 rows but only **357 unique IDs**, meaning a large portion is filtered out by ID conflicts alone.
*   **Foreign Key Constraints**: The `chatbot_companybot` table currently contains only **2 entries**. Since `chatbot_companystatemachine` depends on `company_bot_id`, any row referencing a bot ID not in those 2 entries would fail the foreign key constraint.

---
*Generated on: 2026-04-16*