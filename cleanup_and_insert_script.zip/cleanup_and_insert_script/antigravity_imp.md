# Chatbot Rating Extractor — Implementation Guide

## Overview

This script connects to a PostgreSQL database, pulls 15 unique chatbot session IDs from the `chatbot_companychat` table, extracts satisfaction ratings and reasons from user messages using a local LLM (Mistral via Ollama), and writes the structured output to a timestamped CSV file.

---

## Project Structure

```
rating-extractor/
├── process_ratings.py       # Main script
├── requirements.txt         # Python dependencies
├── .env                     # DB credentials (do not commit)
└── output/
    └── ratings_YYYYMMDD_HHMMSS.csv
```

---

## Database Schema

**Table:** `chatbot_companychat`

| Column | Type | Description |
|---|---|---|
| `id` | integer | Auto-increment primary key |
| `session_id` | varchar | Groups messages into one conversation |
| `stage` | varchar | Survey category (e.g. `EDUCATION_QUALITY_RATING`) |
| `sender_id` | integer | `1` = bot, any other value = user |
| `receiver_id` | integer | Recipient of the message |
| `message` | text | Raw message content |

**Key rules:**
- `sender_id = 1` → bot message (question/prompt)
- `sender_id != 1` → user message (rating or reason)
- Each stage can have **up to 2 user messages**: one numeric rating and one reason text

---

## Categories

```
EDUCATION_QUALITY_RATING        ← rating + reason
PRINCIPAL_SATISFACTION          ← rating + reason
CARETAKER_SATISFACTION          ← rating + reason
TEACHER_COMMUNICATION_RATING    ← rating + reason
CLEANLINESS_RATING              ← rating + reason
DRINKING_WATER_RATING           ← rating + reason
HEALTHCARE_RATING               ← rating + reason
DIET_MENU_RATING                ← rating + reason
SAFETY_MEASURES_RATING          ← rating + reason
EXTRACURRICULAR_RATING          ← rating + reason
OVERALL_SATISFACTION_RATING     ← rating + reason
```

---

## Expected CSV Output

```
session_id, EDUCATION_QUALITY_RATING, EDUCATION_QUALITY_RATING_reason,
PRINCIPAL_SATISFACTION, PRINCIPAL_SATISFACTION_reason,
CARETAKER_SATISFACTION, CARETAKER_SATISFACTION_reason,
TEACHER_COMMUNICATION_RATING, TEACHER_COMMUNICATION_RATING_reason,
CLEANLINESS_RATING, CLEANLINESS_RATING_reason,
DRINKING_WATER_RATING, DRINKING_WATER_RATING_reason,
HEALTHCARE_RATING, HEALTHCARE_RATING_reason,
DIET_MENU_RATING, DIET_MENU_RATING_reason,
SAFETY_MEASURES_RATING, SAFETY_MEASURES_RATING_reason,
EXTRACURRICULAR_RATING, EXTRACURRICULAR_RATING_reason,
OVERALL_SATISFACTION_RATING, OVERALL_SATISFACTION_RATING_reason
```

**Example row:**
```
abc123, 5, "Very satisfied", 4, "Good but could respond faster", 3, "Average", 5, 4, 5, 4, 3, 5, 4, 5
```

---

## Prerequisites

### 1. Python 3.10+
```bash
python --version
```

### 2. Install dependencies
```bash
pip install psycopg2-binary pandas requests python-dotenv
```

Or using the `requirements.txt`:
```
psycopg2-binary==2.9.9
pandas==2.2.2
requests==2.31.0
python-dotenv==1.0.1
```

```bash
pip install -r requirements.txt
```

### 3. Install and start Ollama
Download from [https://ollama.com](https://ollama.com), then:
```bash
# Pull the model (one-time, ~4GB)
ollama pull mistral

# Start the Ollama server (keep this running in background)
ollama serve
```

Verify it's running:
```bash
curl http://localhost:11434/api/tags
```

---

## Environment Setup

Create a `.env` file in the project root:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=mitra_ap_ptm
DB_USER=postgres
DB_PASSWORD=postgres
```

---

## Full Script

```python
import os
import re
import csv
import json
import requests
import psycopg2
import pandas as pd
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "localhost"),
    "port":     int(os.getenv("DB_PORT", 5432)),
    "database": os.getenv("DB_NAME"),
    "user":     os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
}

OLLAMA_URL   = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "mistral"
OUTPUT_CSV   = f"output/ratings_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
BOT_ID       = 1

CATEGORIES = [
    "EDUCATION_QUALITY_RATING",
    "PRINCIPAL_SATISFACTION",
    "CARETAKER_SATISFACTION",
    "TEACHER_COMMUNICATION_RATING",
    "CLEANLINESS_RATING",
    "DRINKING_WATER_RATING",
    "HEALTHCARE_RATING",
    "DIET_MENU_RATING",
    "SAFETY_MEASURES_RATING",
    "EXTRACURRICULAR_RATING",
    "OVERALL_SATISFACTION_RATING",
]

CATEGORIES_WITH_REASON = set(CATEGORIES)

# ── Database ──────────────────────────────────────────────────────────────────
def get_connection():
    return psycopg2.connect(**DB_CONFIG)


def fetch_session_ids(conn, limit=15):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT DISTINCT session_id
        FROM chatbot_companychat
        WHERE stage IN ({placeholders})
        LIMIT %s;
    """
    with conn.cursor() as cur:
        cur.execute(query, (*CATEGORIES, limit))
        return [r[0] for r in cur.fetchall()]


def fetch_session_messages(conn, session_id):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT session_id, stage, sender_id, receiver_id, message
        FROM chatbot_companychat
        WHERE session_id = %s
          AND stage IN ({placeholders})
        ORDER BY id ASC;
    """
    with conn.cursor() as cur:
        cur.execute(query, (session_id, *CATEGORIES))
        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]
    return pd.DataFrame(rows, columns=cols)


# ── LLM ───────────────────────────────────────────────────────────────────────
def build_prompt(session_id, stage_groups):
    convo_text = ""
    for stage, messages in stage_groups.items():
        convo_text += f"\n### STAGE: {stage}\n"
        for m in messages:
            role = "BOT" if m["sender_id"] == BOT_ID else "USER"
            convo_text += f"  [{role}]: {m['message']}\n"

    keys = []
    for cat in CATEGORIES:
        keys.append(f'"{cat}": <integer 1-5 or null>')
        if cat in CATEGORIES_WITH_REASON:
            keys.append(f'"{cat}_reason": "<string or null>"')

    expected_json = "{\n  " + ",\n  ".join(keys) + "\n}"

    return f"""
You are a data extraction assistant. A chatbot survey conversation is grouped below by stage.
Each stage has BOT questions and USER responses.
USER responses contain a numeric rating (1-5) and sometimes a reason text.

Rules:
- Extract the numeric rating (1-5) for every stage. Use null if not found.
- Extract the reason text for stages that have one. Use null if not found.
- Only extract from USER messages. Ignore BOT messages.
- Return ONLY valid JSON. No markdown. No explanation. No extra text.

SESSION: {session_id}

CONVERSATION:
{convo_text}

Expected JSON:
{expected_json}
""".strip()


def call_ollama(prompt):
    payload = {
        "model":  OLLAMA_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.0, "num_predict": 512},
    }
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=60)
        resp.raise_for_status()
        raw = resp.json().get("response", "")
        cleaned = re.sub(r"```(?:json)?|```", "", raw).strip()
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            print(f"  ⚠️  No JSON block found. Raw:\n{raw[:300]}")
            return {}
        return json.loads(match.group())
    except json.JSONDecodeError as e:
        print(f"  ❌ JSON parse error: {e}")
        return {}
    except requests.RequestException as e:
        print(f"  ❌ Ollama error: {e}")
        return {}


# ── CSV ───────────────────────────────────────────────────────────────────────
def build_csv_columns():
    cols = ["session_id"]
    for cat in CATEGORIES:
        cols.append(cat)
        if cat in CATEGORIES_WITH_REASON:
            cols.append(f"{cat}_reason")
    return cols


def build_csv_row(session_id, extracted):
    row = {"session_id": session_id}
    for cat in CATEGORIES:
        row[cat] = extracted.get(cat)
        if cat in CATEGORIES_WITH_REASON:
            row[f"{cat}_reason"] = extracted.get(f"{cat}_reason")
    return row


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    os.makedirs("output", exist_ok=True)

    print("🔌 Connecting to database...")
    conn = get_connection()

    print("📋 Fetching 15 session IDs...")
    session_ids = fetch_session_ids(conn, limit=15)
    print(f"  Found {len(session_ids)} sessions.\n")

    csv_columns = build_csv_columns()
    all_rows = []

    for idx, sid in enumerate(session_ids, 1):
        print(f"[{idx}/{len(session_ids)}] Session: {sid}")

        df = fetch_session_messages(conn, sid)
        if df.empty:
            print("  ⚠️  No messages — skipping.")
            all_rows.append({"session_id": sid})
            continue

        stage_groups = {
            stage: group[["sender_id", "message"]].to_dict("records")
            for stage, group in df.groupby("stage", sort=False)
        }

        prompt    = build_prompt(sid, stage_groups)
        extracted = call_ollama(prompt)
        print(f"  ✅ {json.dumps(extracted, ensure_ascii=False)}")

        all_rows.append(build_csv_row(sid, extracted))

    conn.close()

    print(f"\n💾 Writing to {OUTPUT_CSV}...")
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=csv_columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"✅ Done → {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
```

---

## Running the Script

```bash
# 1. Make sure Ollama is serving (separate terminal)
ollama serve

# 2. Run the extractor
python process_ratings.py
```

---

## Data Flow Diagram

```
PostgreSQL (chatbot_companychat)
        │
        ▼
fetch_session_ids()        → 15 unique session_ids
        │
        ▼ (for each session)
fetch_session_messages()   → raw rows filtered by CATEGORIES
        │
        ▼
group by stage             → { STAGE_NAME: [{sender_id, message}, ...] }
        │
        ▼
build_prompt()             → structured prompt with full conversation
        │
        ▼
call_ollama() [Mistral]    → raw JSON string
        │
        ▼
regex + json.loads()       → clean Python dict
        │
        ▼
build_csv_row()            → flat dict with all column keys
        │
        ▼
csv.DictWriter             → output/ratings_YYYYMMDD_HHMMSS.csv
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `connection refused` on DB | Check `.env` values and that PostgreSQL is running |
| `connection refused` on Ollama | Run `ollama serve` in a separate terminal |
| LLM returns empty `{}` | Check `ollama serve` logs; try `ollama pull mistral` again |
| Ratings all `null` | Print the raw prompt and verify `stage` values match exactly |
| CSV has no rows | Confirm `chatbot_companychat` table name and column names match |
| Slow execution | Reduce `num_predict` to 256 or switch to `llama3.2:3b` (faster, smaller) |

---

## Notes

- `temperature: 0.0` is intentional — keeps LLM output deterministic for structured extraction
- Bot messages are included in the prompt so the LLM understands the context of each question
- The CSV filename is timestamped so repeated runs never overwrite previous output
- If a session has no data for a category, that cell will be `null` in the CSV