import os
import re
import csv
import json
import psycopg2
import pandas as pd
import argparse
from datetime import datetime
from dotenv import load_dotenv

# Import sentence-transformers
from sentence_transformers import SentenceTransformer, util

load_dotenv()

# ── Config ────────────────────────────────────────────────────────────────────
DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "localhost"),
    "port":     int(os.getenv("DB_PORT", 5432)),
    "database": os.getenv("DB_NAME", "mitra_ap_ptm"),
    "user":     os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "postgres"),
}

OUTPUT_CSV = f"output/ratings_semantic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
BOT_ID     = 1

CATEGORIES = [
    "EDUCATION_QUALITY_RATING",
    "PRINCIPAL_SATISFACTION",
    "CARETAKER_SATISFACTION",
    "TEACHER_COMMUNICATION_RATING",
    "CLEANLINESS_RATING",
    "DRINKING_WATER_RATING",
    "HEALTHCARE_RATING",
    "DIET_MENU_RATING",
    "SAFETY_MEASURES_RATING",
    "EXTRACURRICULAR_RATING",
    "OVERALL_SATISFACTION_RATING",
]

CATEGORIES_WITH_REASON = set(CATEGORIES)

# ── Semantic Model Initialization ──────────────────────────────────────────────
# Load the model strictly locally after first download
print("Loading sentence-transformers/all-MiniLM-L6-v2...")
embed_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Define strong semantic anchors for 1 to 5 ratings
RATING_ANCHORS = {
    1: ["terrible", "very bad", "completely unsatisfied", "horrible", "worst", "unacceptable"],
    2: ["bad", "poor", "unsatisfied", "disappointed", "not good"],
    3: ["okay", "average", "neutral", "fine", "acceptable", "mediocre"],
    4: ["good", "satisfied", "nice", "well done", "pleasant"],
    5: ["excellent", "very good", "great", "awesome", "perfect", "highly satisfied", "outstanding"]
}

print("Pre-computing anchor embeddings...")
anchor_embeddings = {
    rating: embed_model.encode(texts, convert_to_tensor=True)
    for rating, texts in RATING_ANCHORS.items()
}

# ── Extraction Logic ──────────────────────────────────────────────────────────
def extract_rating_and_reason(user_text):
    """
    Extracts the rating (1-5) and reason from user text using a hybrid approach:
    1. Direct Regex (fast, highly accurate for clear numbers)
    2. Semantic similarity fallback (for text like "it was excellent")
    """
    if not user_text:
        return None, None
        
    text = str(user_text).strip()
    if not text:
        return None, None
        
    extracted_rating = None
    
    # Check for direct number rating (e.g. "5", "4/5", "I give it a 3")
    explicit_match = re.search(r'\b([1-5])(?:\s*/\s*5)?\b', text)
    
    if explicit_match:
        extracted_rating = int(explicit_match.group(1))
    else:
        # Fallback to Semantic Similarity Classification
        text_emb = embed_model.encode(text, convert_to_tensor=True)
        best_rating = None
        highest_score = -1.0
        
        # Compare against all anchors
        for rating, anchors_emb in anchor_embeddings.items():
            scores = util.cos_sim(text_emb, anchors_emb)
            max_score = float(scores.max())
            
            if max_score > highest_score:
                highest_score = max_score
                best_rating = rating
                
        # Threshold: ensure we aren't strongly matching out-of-context random words
        # (Tune this threshold based on tests, 0.25 is a safe start for MiniLM)
        if highest_score > 0.25:
            extracted_rating = best_rating
            
    # For semantic extraction, the text itself *is* the reason.
    # If the user just typed "5", reason is None. 
    reason = text if len(text) > 2 else None
    
    return extracted_rating, reason


# ── Database & Execution ──────────────────────────────────────────────────────
def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def fetch_session_ids(conn, limit=15):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT DISTINCT session AS session_id
        FROM chatbot_companychat
        WHERE stage IN ({placeholders})
        LIMIT %s;
    """
    with conn.cursor() as cur:
        cur.execute(query, (*CATEGORIES, limit))
        return [r[0] for r in cur.fetchall()]

def fetch_session_messages(conn, session_id):
    placeholders = ",".join(["%s"] * len(CATEGORIES))
    query = f"""
        SELECT session AS session_id, stage, sender_id, message, translated_message
        FROM chatbot_companychat
        WHERE session = %s
          AND stage IN ({placeholders})
        ORDER BY id ASC;
    """
    with conn.cursor() as cur:
        cur.execute(query, (session_id, *CATEGORIES))
        rows = cur.fetchall()
        cols = [desc[0] for desc in cur.description]
    return pd.DataFrame(rows, columns=cols)

def build_csv_row(session_id, extracted):
    row = {"session_id": session_id}
    for cat in CATEGORIES:
        row[cat] = extracted.get(cat)
        if cat in CATEGORIES_WITH_REASON:
            row[f"{cat}_reason"] = extracted.get(f"{cat}_reason")
    return row

def build_csv_columns():
    cols = ["session_id"]
    for cat in CATEGORIES:
        cols.append(cat)
        if cat in CATEGORIES_WITH_REASON:
            cols.append(f"{cat}_reason")
    return cols

def main():
    parser = argparse.ArgumentParser(description="Extract chatbot ratings locally via CPU/Semantic similarity")
    parser.add_argument("session_id", type=str, nargs="?", help="Optional specific session ID to process")
    parser.add_argument("--limit", type=int, default=15, help="Number of sessions to process in batch mode")
    args = parser.parse_args()

    os.makedirs("output", exist_ok=True)
    conn = get_connection()

    if args.session_id:
        session_ids = [args.session_id]
        output_csv = f"output/rating_sem_{args.session_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    else:
        session_ids = fetch_session_ids(conn, limit=args.limit)
        output_csv = OUTPUT_CSV

    print(f"📋 Processing {len(session_ids)} sessions using Semantic embeddings...")
    
    all_rows = []
    
    for sid in session_ids:
        df = fetch_session_messages(conn, sid)
        if df.empty:
            all_rows.append({"session_id": sid})
            continue

        stage_groups = df.groupby("stage", sort=False)
        extracted = {}

        for stage, group in stage_groups:
            # Collect user's text for this stage
            user_texts = []
            for _, m in group.iterrows():
                if m["sender_id"] != BOT_ID:
                    # Prefer English translation over raw native text
                    msg_text = m.get("message")
                    translated = m.get("translated_message")
                    if pd.notna(translated) and str(translated).strip():
                        msg_text = str(translated).strip()
                    
                    if pd.notna(msg_text) and str(msg_text).strip():
                        user_texts.append(str(msg_text).strip())
            
            combined_text = " ".join(user_texts)
            rating, reason = extract_rating_and_reason(combined_text)
            
            extracted[stage] = rating
            extracted[f"{stage}_reason"] = reason

        row = build_csv_row(sid, extracted)
        all_rows.append(row)
        
        # Format the extracted data for JSON printing (exclude session_id for the log)
        log_json = {k: v for k, v in row.items() if k != "session_id"}
        print(f"  ✅ [Session {sid}] {json.dumps(log_json, ensure_ascii=False)}")

    conn.close()

    if all_rows:
        with open(output_csv, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=build_csv_columns(), extrasaction="ignore")
            writer.writeheader()
            writer.writerows(all_rows)
        print(f"\n💾 Saved {len(all_rows)} rows to {output_csv}")

if __name__ == "__main__":
    main()
