import os
import psycopg2
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "host":     os.getenv("DB_HOST", "localhost"),
    "port":     int(os.getenv("DB_PORT", 5432)),
    "database": os.getenv("DB_NAME", "mitra_ap_ptm"),
    "user":     os.getenv("DB_USER", "postgres"),
    "password": os.getenv("DB_PASSWORD", "postgres"),
}

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def load_categories_order():
    stages = []
    with open("categories.txt", "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            # If the line is an all-caps stage word like INTRODUCTION
            if line and line.isupper() and not " " in line and line.isalpha() or "_" in line:
                if line not in stages:
                    stages.append(line)
    return {stage: idx+1 for idx, stage in enumerate(stages)}

def main():
    print("🔌 Connecting to database for analysis...\n")
    conn = get_connection()
    cur = conn.cursor()

    os.makedirs("output", exist_ok=True)
    report_file = "output/analysis_report.txt"

    with open(report_file, "w", encoding="utf-8") as rf:
        def log(msg, list_data=None):
            print(msg)
            rf.write(msg + "\n")
            if list_data is not None:
                list_str = str(list_data)
                if len(list_str) > 500:
                    rf.write(f"  -> List ({len(list_data)} items): {list_str[:500]} ... [truncated]\n\n")
                else:
                    rf.write(f"  -> List ({len(list_data)} items): {list_str}\n\n")

        log("="*60)
        log(" CHATBOT USER & SESSION ANALYSIS REPORT")
        log("="*60 + "\n")

        # 1. Count and List all the users present in both tables
        cur.execute("""
            SELECT DISTINCT p.id 
            FROM chatbot_profile p 
            INNER JOIN chatbot_companychat c ON p.id::text = c.sender_id::text
        """)
        intersect = sorted([row[0] for row in cur.fetchall()])
        log(f"1. Users in BOTH chatbot_profile AND chatbot_companychat: {len(intersect)}", intersect)

        # 2. Count and List all the users present in chatbot_profile but not in chatbot_companychat
        cur.execute("""
            SELECT DISTINCT p.id 
            FROM chatbot_profile p
            LEFT JOIN chatbot_companychat c ON p.id::text = c.sender_id::text
            WHERE c.sender_id IS NULL
        """)
        only_prof = sorted([row[0] for row in cur.fetchall()])
        log(f"2. Users ONLY in chatbot_profile (Not in chat): {len(only_prof)}", only_prof)

        # 3. Count and List all the users present in chatbot_companychat but not in chatbot_profile
        # We exclude BOT (id 1 or '1060' mappings)
        cur.execute("""
            SELECT DISTINCT c.sender_id 
            FROM chatbot_companychat c
            LEFT JOIN chatbot_profile p ON c.sender_id::text = p.id::text
            WHERE p.id IS NULL
        """)
        only_chat = sorted([row[0] for row in cur.fetchall() if str(row[0]) != '1' and '060' not in str(row[0])])
        log(f"3. Users ONLY in chatbot_companychat (Not in profile): {len(only_chat)}", only_chat)

        # 4. Count and List of all the unique sessions
        cur.execute("SELECT DISTINCT session FROM chatbot_companychat WHERE session IS NOT NULL")
        uniq_sessions = sorted([row[0] for row in cur.fetchall()])
        log(f"4. Unique Sessions in chatbot_companychat: {len(uniq_sessions)}", uniq_sessions)

        # 5. Count and List of all the sender_ids
        cur.execute("SELECT DISTINCT sender_id FROM chatbot_companychat WHERE sender_id IS NOT NULL")
        uniq_senders = sorted([row[0] for row in cur.fetchall()])
        log(f"5. Unique Sender IDs in chatbot_companychat: {len(uniq_senders)}", uniq_senders)

        # 6. Count and List same sender_ids and different session ids
        cur.execute("""
            SELECT sender_id, COUNT(DISTINCT session) as session_count, array_agg(DISTINCT session)
            FROM chatbot_companychat 
            WHERE sender_id IS NOT NULL
            GROUP BY sender_id 
            HAVING COUNT(DISTINCT session) > 1
        """)
        multi_session_users = cur.fetchall()
        ms_dict = {row[0]: row[2] for row in multi_session_users}
        log(f"6. Sender IDs with multiple different session IDs: {len(multi_session_users)}", ms_dict)

        # 7. How many sessions are in stage = 'CLOSING'
        cur.execute("SELECT DISTINCT session FROM chatbot_companychat WHERE stage = 'CLOSING'")
        closing_sessions = sorted([row[0] for row in cur.fetchall()])
        log(f"7. Sessions that reached 'CLOSING' stage: {len(closing_sessions)}", closing_sessions)

        # 8. List the stage name and number (refer to categories.txt) for all the unique sender_id take the max stage id
        stages_order = load_categories_order()
        cur.execute("""
            SELECT sender_id, stage, id
            FROM chatbot_companychat
            WHERE sender_id IS NOT NULL
        """)
        df = pd.DataFrame(cur.fetchall(), columns=['sender_id', 'stage', 'id'])
        
        # Map stages to numbers
        df['stage_num'] = df['stage'].map(stages_order).fillna(0).astype(int)
        
        # Group by sender, get the row with the maximum stage_num
        idx_max = df.groupby('sender_id')['stage_num'].idxmax()
        max_stages_df = df.loc[idx_max].sort_values(by='stage_num', ascending=False)
        
        # Format the result list
        sender_max_stages = max_stages_df[['sender_id', 'stage', 'stage_num']].to_dict(orient='records')
        
        log(f"8. Max Stage reached for each Sender ID: {len(sender_max_stages)}")
        rf.write("  -> Details:\n")
        print("  -> (Detailed list saved to report file)")
        for record in sender_max_stages:
            rf.write(f"      Sender: {record['sender_id']} | Stage: {record['stage']} (Stage #{record['stage_num']})\n")

    conn.close()
    print(f"\n✅ Full analysis complete. Report generously saved to: {report_file}")

if __name__ == "__main__":
    main()
