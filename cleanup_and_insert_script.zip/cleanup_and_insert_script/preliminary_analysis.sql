-- ============================================================
-- AP PTM SURVEY — PRELIMINARY ANALYSIS QUERIES
-- Database: mitra_ap_ptm
-- Date: 2026-04-20
-- ============================================================


-- ── 1. TOTAL UNIQUE REGISTERED USERS (excluding bot) ─────────────────────────
-- Result: 16,103
-- Note: 128 users are missing 'district' and 'schoolName' in their profile.
--       Is there an alternate source to retrieve this data?

SELECT COUNT(DISTINCT id)
FROM chatbot_profile
WHERE id != 1;


-- ── 2. TOTAL CONVERSATION ENTRIES ────────────────────────────────────────────
-- Result: 618,067

SELECT COUNT(*)
FROM chatbot_companychat;


-- ── 3. TOTAL UNIQUE SESSIONS ──────────────────────────────────────────────────
-- Result: 25,813

SELECT COUNT(DISTINCT session)
FROM chatbot_companychat;


-- ── 4. TOTAL UNIQUE SENDERS (excluding bot) ───────────────────────────────────
-- Result: 15,329
-- Note: User IDs 17 and 22 sent messages but received no bot response. Why?

SELECT COUNT(DISTINCT sender_id)
FROM chatbot_companychat
WHERE sender_id != 1;


-- ── 5. TOTAL UNIQUE RECEIVERS (excluding bot) ─────────────────────────────────
-- Result: 15,327
-- Note: 2 fewer receivers than senders — User IDs 17 and 22 are the gap.

SELECT COUNT(DISTINCT receiver_id)
FROM chatbot_companychat
WHERE receiver_id != 1;


-- ── 6. TOTAL SESSIONS THAT REACHED THE CLOSING STAGE ─────────────────────────
-- Result: 16,481
-- Note: This represents all sessions (including repeat submissions) that
--       completed the full survey flow.

SELECT COUNT(DISTINCT session)
FROM chatbot_companychat
WHERE stage = 'CLOSING';


-- ── 7. TOTAL UNIQUE USERS WHO COMPLETED THE SURVEY ───────────────────────────
-- Result: 13,406
-- Note: Considers both sender_id and receiver_id to avoid double-counting.
--       Gap vs registered users (16,103 - 13,406 = 2,697) are users who
--       never completed or never participated.

SELECT COUNT(DISTINCT user_id)
FROM (
    SELECT sender_id AS user_id
    FROM chatbot_companychat
    WHERE stage = 'CLOSING'
      AND sender_id != 1
    UNION
    SELECT receiver_id AS user_id
    FROM chatbot_companychat
    WHERE stage = 'CLOSING'
      AND receiver_id != 1
) t;


-- ── 8. SESSION COUNT PER USER (who completed the survey) ─────────────────────
-- Note: Shows repeat submissions. Ordered highest to lowest.
--       Total sessions (16,481) vs unique users (13,406) = 3,075 repeat sessions
--       from 2,309 users who submitted more than once.

SELECT user_id, COUNT(DISTINCT session) AS session_count
FROM (
    SELECT sender_id AS user_id, session
    FROM chatbot_companychat
    WHERE stage = 'CLOSING'
      AND sender_id != 1
      AND sender_id IS NOT NULL
    UNION
    SELECT receiver_id AS user_id, session
    FROM chatbot_companychat
    WHERE stage = 'CLOSING'
      AND receiver_id != 1
      AND receiver_id IS NOT NULL
) t
GROUP BY user_id
ORDER BY session_count DESC;


-- ── 9. ROWS WITH BOTH SENDER AND RECEIVER AS NULL ────────────────────────────
-- Result: 8 entries
-- Note: Both sender_id and receiver_id are NULL. Need to understand the senario:

SELECT *
FROM chatbot_companychat
WHERE sender_id IS NULL
  AND receiver_id IS NULL;


-- ── 10. COMBINED — USERS MISSING DISTRICT OR SCHOOL NAME ─────────────────────
-- Note: A user appears here if EITHER field is missing.
--       'district_missing' and 'school_missing' flags show which field(s) are affected.

SELECT
    id,
    other_params->>'district'   AS district,
    other_params->>'schoolName' AS school_name,
    CASE WHEN other_params IS NULL
          OR other_params->>'district' IS NULL
          OR TRIM(other_params->>'district') = ''
          OR other_params->>'district' = 'null'
         THEN 'YES' ELSE 'NO' END AS district_missing,
    CASE WHEN other_params IS NULL
          OR other_params->>'schoolName' IS NULL
          OR TRIM(other_params->>'schoolName') = ''
          OR other_params->>'schoolName' = 'null'
         THEN 'YES' ELSE 'NO' END AS school_missing
FROM chatbot_profile
WHERE id != 1
  AND (
    other_params IS NULL
    OR other_params->>'district' IS NULL
    OR TRIM(other_params->>'district') = ''
    OR other_params->>'district' = 'null'
    OR other_params->>'schoolName' IS NULL
    OR TRIM(other_params->>'schoolName') = ''
    OR other_params->>'schoolName' = 'null'
  )
ORDER BY id;


-- ============================================================
-- SUMMARY OF KEY NUMBERS
-- ============================================================
--
--  Registered users (excl. bot)          : 16,103
--  Total conversation entries            : 618,067
--  Total unique sessions                 : 25,813
--  Unique senders (excl. bot)            : 15,329
--  Unique receivers (excl. bot)          : 15,327
--  Sessions at CLOSING stage             : 16,481
--  Unique users who completed survey     : 13,406
--  Repeat sessions                       :  3,075  (from 2,309 repeat users)
--  Users missing district or schoolName  :    128
--  NULL sender + receiver rows           :      8
-- ============================================================